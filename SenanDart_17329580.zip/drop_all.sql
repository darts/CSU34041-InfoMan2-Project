-- Senán d'Art
-- 17329580

drop table branch,bcommit, cchange, ccomment, repo, user;
