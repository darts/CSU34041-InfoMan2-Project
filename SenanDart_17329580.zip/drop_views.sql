-- Senán d'Art
-- 17329580

drop view not_logged_in_repos;
drop view newest_ten_commits;
