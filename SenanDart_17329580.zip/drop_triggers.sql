-- Senán d'Art
-- 17329580

drop trigger repo_check;
drop trigger update_latest_commit;
drop trigger curr_time_user;
drop trigger curr_time_repo;
drop trigger curr_time_branch;
drop trigger curr_time_bcommit;
drop trigger curr_time_ccomment;
